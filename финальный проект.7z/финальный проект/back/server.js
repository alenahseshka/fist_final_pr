const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = 5668;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const dataPath = path.join(__dirname, "countries.json");
const countries = JSON.parse(fs.readFileSync(dataPath, "utf-8"));

app.get("/countries", (req, res) => {
  res.json(
    countries.map(c => ({
      code: c.cca3,
      name: c.name.common,
      flag: c.flag,
      region: c.region,
      capital: c.capital?.[0] || "—",
      population: c.population,
      area: c.area
    }))
  );
});

app.get("/countries/:code", (req, res) => {
  const code = req.params.code.toUpperCase();
  const country = countries.find(c => c.cca3 === code);
  if (!country) return res.status(404).json({ error: "Country not found" });
  res.json(country);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});