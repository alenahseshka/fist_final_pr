console.log("app.js loaded");

const listEl = document.getElementById("list");
const tableEl = document.getElementById("table");
const tableBody = tableEl.querySelector('tbody');
const qEl = document.getElementById("q");
const regionEl = document.getElementById("region");
const popMinEl = document.getElementById("popMin");
const popMaxEl = document.getElementById("popMax");
const areaMinEl = document.getElementById("areaMin");
const areaMaxEl = document.getElementById("areaMax");
const sortEl = document.getElementById("sort");
const body = document.body;

let all = [];
let currentView = 'grid';

function sortCountries(arr, mode) {
  const copy = [...arr];
  if (mode === "name") copy.sort((a, b) => a.name.localeCompare(b.name));
  if (mode === "population") copy.sort((a, b) => (b.population ?? 0) - (a.population ?? 0));
  if (mode === "area") copy.sort((a, b) => (b.area ?? 0) - (a.area ?? 0));
  return copy;
}

function searchInTranslations(country, query) {
  if (!country.translations) return false;
  const translations = Object.values(country.translations);
  return translations.some(trans => 
    trans.common?.toLowerCase().includes(query) || 
    trans.official?.toLowerCase().includes(query)
  );
}

function renderGrid(items) {
  listEl.innerHTML = items.map(c => `
    <a href="country.html?code=${c.code}" class="item">
      <div class="name">${c.flag ?? ""} ${c.name}</div>
      <div class="meta">${c.region ?? ""} • ${c.capital ?? "—"}</div>
      <div class="meta">Pop: ${(c.population ?? 0).toLocaleString()} • Area: ${(c.area ?? 0).toLocaleString()} km²</div>
    </a>
  `).join("");
}

function renderTable(items) {
  tableBody.innerHTML = items.map(c => `
    <tr>
      <td>${c.flag ?? ""}</td>
      <td>${c.name}</td>
      <td>${c.region ?? ""}</td>
      <td>${c.capital ?? "—"}</td>
      <td>${(c.population ?? 0).toLocaleString()}</td>
      <td>${(c.area ?? 0).toLocaleString()}</td>
      <td><a href="country.html?code=${c.code}" class="btn">View</a></td>
    </tr>
  `).join("");
}

function render(items) {
  if (currentView === 'grid') {
    listEl.classList.remove('hidden');
    tableEl.classList.add('hidden');
    renderGrid(items);
  } else {
    listEl.classList.add('hidden');
    tableEl.classList.remove('hidden');
    renderTable(items);
  }
}

function applyFilters() {
  const q = (qEl.value || "").trim().toLowerCase();
  const region = regionEl.value;
  const popMin = popMinEl.value ? Number(popMinEl.value) : null;
  const popMax = popMaxEl.value ? Number(popMaxEl.value) : null;
  const areaMin = areaMinEl.value ? Number(areaMinEl.value) : null;
  const areaMax = areaMaxEl.value ? Number(areaMaxEl.value) : null;
  const mode = sortEl.value;

  let result = all.filter(c => {
    const nameMatch = (c.name || "").toLowerCase().includes(q);
    const translationMatch = searchInTranslations(c, q);
    const regionMatch = !region || c.region === region;
    const popMatch = (!popMin || (c.population ?? 0) >= popMin) && 
                     (!popMax || (c.population ?? 0) <= popMax);
    const areaMatch = (!areaMin || (c.area ?? 0) >= areaMin) && 
                      (!areaMax || (c.area ?? 0) <= areaMax);
    
    return (nameMatch || translationMatch) && regionMatch && popMatch && areaMatch;
  });

  result = sortCountries(result, mode);
  render(result);
}

function setTheme(theme) {
  body.setAttribute('data-theme', theme);
  localStorage.setItem('theme', theme);
  
  document.querySelectorAll('.theme-switcher button').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.theme === theme);
  });
}

function setView(view) {
  currentView = view;
  localStorage.setItem('view', view);
  applyFilters();
  
  document.querySelectorAll('.view-switcher button').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.view === view);
  });
}

async function load() {
  try {
    const res = await fetch("/countries");
    all = await res.json();
    
    const savedTheme = localStorage.getItem('theme') || 'system';
    const savedView = localStorage.getItem('view') || 'grid';
    
    setTheme(savedTheme);
    setView(savedView);
    applyFilters();
  } catch (error) {
    console.error("Failed to load countries:", error);
    listEl.innerHTML = '<div class="error">Failed to load countries data</div>';
  }
}

[qEl, regionEl, popMinEl, popMaxEl, areaMinEl, areaMaxEl, sortEl].forEach(el => {
  el.addEventListener("input", applyFilters);
  el.addEventListener("change", applyFilters);
});

document.querySelectorAll('.theme-switcher button').forEach(btn => {
  btn.addEventListener('click', () => setTheme(btn.dataset.theme));
});

document.querySelectorAll('.view-switcher button').forEach(btn => {
  btn.addEventListener('click', () => setView(btn.dataset.view));
});

const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
function handleSystemThemeChange(e) {
  if (body.getAttribute('data-theme') === 'system') {
    body.classList.toggle('dark-mode', e.matches);
  }
}
mediaQuery.addEventListener('change', handleSystemThemeChange);
handleSystemThemeChange(mediaQuery);

load();