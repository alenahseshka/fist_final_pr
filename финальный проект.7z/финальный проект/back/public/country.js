const urlParams = new URLSearchParams(window.location.search);
const code = urlParams.get('code');

const countryNameEl = document.getElementById("countryName");
const countryNativeNameEl = document.getElementById("countryNativeName");
const flagImageEl = document.getElementById("flagImage");
const detailsEl = document.getElementById("details");
let map = null;

function setTheme(theme) {
  document.body.setAttribute('data-theme', theme);
  localStorage.setItem('theme', theme);
  
  document.querySelectorAll('.theme-switcher button').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.theme === theme);
  });
}

function initMap(lat, lng) {
  if (map) map.remove();
  
  map = L.map('map').setView([lat, lng], 5);
  
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
  }).addTo(map);
  
  L.marker([lat, lng])
    .addTo(map)
    .bindPopup('Country location')
    .openPopup();
}

async function loadCountry() {
  if (!code) {
    detailsEl.innerHTML = "<p>Country not found.</p>";
    return;
  }

  try {
    const res = await fetch(`/countries/${code}`);
    const country = await res.json();

    if (country.code) {
      flagImageEl.src = `https://flagcdn.com/w320/${country.code.toLowerCase()}.png`;
      flagImageEl.onerror = () => {
        flagImageEl.src = 'https://flagcdn.com/w320/unknown.png';
      };
    }

    countryNameEl.textContent = `${country.flag ?? ""} ${country.name}`;
    
    const nativeName = country.translations?.rus?.official || 
                       country.translations?.fra?.official ||
                       country.nameNative || 
                       country.name;
    countryNativeNameEl.textContent = nativeName;

    detailsEl.innerHTML = `
      <div class="detail-item"><strong>Region:</strong> ${country.region || "—"}</div>
      <div class="detail-item"><strong>Subregion:</strong> ${country.subregion || "—"}</div>
      <div class="detail-item"><strong>Capital:</strong> ${country.capital || "—"}</div>
      <div class="detail-item"><strong>Population:</strong> ${(country.population || 0).toLocaleString()}</div>
      <div class="detail-item"><strong>Area:</strong> ${(country.area || 0).toLocaleString()} km²</div>
      <div class="detail-item"><strong>Languages:</strong> ${country.languages ? Object.values(country.languages).join(", ") : "—"}</div>
      <div class="detail-item"><strong>Currencies:</strong> ${country.currencies ? Object.values(country.currencies).map(c => c.name).join(", ") : "—"}</div>
      <div class="detail-item"><strong>Timezones:</strong> ${country.timezones ? country.timezones.join(", ") : "—"}</div>
      <div class="detail-item"><strong>Borders:</strong> ${country.borders ? country.borders.join(", ") : "—"}</div>
      <div class="detail-item"><strong>Domain:</strong> ${country.tld ? country.tld.join(", ") : "—"}</div>
    `;

    if (country.latlng && country.latlng.length >= 2) {
      initMap(country.latlng[0], country.latlng[1]);
    } else {
      document.querySelector('.map-section').innerHTML = '<p>Map not available for this country</p>';
    }

  } catch (error) {
    console.error("Failed to load country:", error);
    detailsEl.innerHTML = "<p>Failed to load country data.</p>";
  }
}

document.querySelectorAll('.theme-switcher button').forEach(btn => {
  btn.addEventListener('click', () => setTheme(btn.dataset.theme));
});

const savedTheme = localStorage.getItem('theme') || 'system';
setTheme(savedTheme);

const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
function handleSystemThemeChange(e) {
  const currentTheme = document.body.getAttribute('data-theme');
  if (currentTheme === 'system') {
    document.body.classList.toggle('dark-mode', e.matches);
  }
}
mediaQuery.addEventListener('change', handleSystemThemeChange);
handleSystemThemeChange(mediaQuery);

loadCountry();